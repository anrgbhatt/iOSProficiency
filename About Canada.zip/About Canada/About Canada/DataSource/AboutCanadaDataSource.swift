//
//  AboutCanadaDataSource.swift
//  About Canada
//
//  Created by apple on 6/11/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
import UIKit
class AboutCanadaDataSource: NSObject, UITableViewDataSource {
    var aboutCanada: [AboutCanada]?
    
     init(data:[AboutCanada]) {
        self.aboutCanada = data
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.aboutCanada?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:CanadaInfoTableViewCell?
        cell = tableView.dequeueReusableCell(withIdentifier: GlobalConst.canadaTableViewIdentifier)! as? CanadaInfoTableViewCell
        let des = self.aboutCanada![indexPath.row]
        cell?.dscription.text = des.description
        cell?.title.text = des.title
        //self.title = des.countryTitle
        
        cell?.img.sd_setImage(with: URL(string: des.Image!), placeholderImage: UIImage(named: GlobalConst.tableviewPlaceholderImg))
        return cell!
    }

}
