//
//  Extentions.swift
//  About Canada
//
//  Created by apple on 6/10/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
import UIKit

// Shadow for tableview cell
extension UIView {
    func shadowCell(){
        layer.cornerRadius = 5
        backgroundColor = UIColor.white
        layer.shadowColor = UIColor.lightGray.cgColor
        layer.shadowOpacity = 1
        layer.shadowOffset = CGSize.zero
        layer.shadowRadius = 3
        
    }
}
