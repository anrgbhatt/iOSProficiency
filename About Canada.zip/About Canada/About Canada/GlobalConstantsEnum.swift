//
//  GlobalConstantsEnum.swift
//  About Canada
//
//  Created by apple on 6/10/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

enum GlobalConst {
  //  static let foo = URL(string: "domain/models/foo")!
    static let canadaTableViewIdentifier = "CellContactorListTableViewCell"
    static let tableRefreshMsg = "Refreshing.."
    static let tableviewPlaceholderImg = "placeholder-image"
    static let tableviewNoDataMsg = "No Data found!"
    static let noInternetMsg = "No internet conection!"
    static let errorText = "Error"
    
}
