//
//  AboutCanada.swift
//  About Canada
//
//  Created by apple on 5/31/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation

struct AboutCanada {
    let countryTitle :String
    let title: String?
    let description: String?
    let Image: String?
    
    init(dictionary: AboutCanadaData,countryTitle:String) {
        
        self.title = dictionary["title"] as? String
        self.description = dictionary["description"] as? String
        self.Image = ((dictionary["imageHref"] as? String) == nil ) ? "" : dictionary["imageHref"] as? String
        self.countryTitle = countryTitle
    }
    
}
