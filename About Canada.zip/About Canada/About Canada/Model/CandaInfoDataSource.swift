//
//  CandaInfoDataSource.swift
//  About Canada
//
//  Created by apple on 5/31/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON
final class CandaInfoDataSource {
    
    static let sharedInstance = CandaInfoDataSource()
    fileprivate init() {}
    
    var aboutCanada: [AboutCanada] = []
    
    func getData(url:String ,completion: @escaping ([AboutCanada]) -> Void) {
        
        APIClient.getCanadaInfoAPI(url: url) { (json) in
        if let results = json {
            print(JSON(results))
            let countryTitle =  results["title"] as! String
            let arrRows = results["rows"] as? [AboutCanadaData]
            for dict in arrRows! {
                print(JSON(dict))
                
                if(self.isDictinaryContainsAllValues(dict: dict)){
                    let newDicRow = AboutCanada(dictionary: dict , countryTitle: countryTitle)
                    self.aboutCanada.append(newDicRow)
                }
            }
                completion(self.aboutCanada)
        }else{
                completion(self.aboutCanada)
            }
        }
        
}
    
  fileprivate  func isDictinaryContainsAllValues(dict:AboutCanadaData) ->Bool{
        if(((dict["description"] as? String) == nil) && ((dict["title"] as? String) == nil) && ((dict["imageHref"] as? String) == nil)) {
            return false
        }else{
            return true
        }
    }
}
