//
//  File.swift
//  About Canada
//
//  Created by apple on 5/31/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON
typealias AboutCanadaData = [String: Any]

struct APIClient {

    static func getCanadaInfoAPI(url:String ,completion: @escaping (AboutCanadaData?) -> Void) {
        Alamofire.request(url).responseJSON { (responseData) -> Void in
            let encode = NSString.init(data: responseData.data!, encoding: String.Encoding.isoLatin1.rawValue)
            let newData = encode!.data(using:String.Encoding.utf8.rawValue)
            let json = try! JSONSerialization.jsonObject(with: newData!, options: []) as! NSDictionary
           // print(JSON(json))
                let swiftyJsonVar = JSON(json)
                if let resData = swiftyJsonVar.dictionaryObject {
                   completion(resData)
                }else{
                   completion(nil)
                }
        }
    
    }
}
