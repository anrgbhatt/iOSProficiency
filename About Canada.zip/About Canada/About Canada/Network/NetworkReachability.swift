//
//  NetworkReachability.swift
//  About Canada
//
//  Created by apple on 6/6/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
import Alamofire
class NetworkObserver {
    class func isConnectedToInternet() -> Bool {
        return NetworkReachabilityManager()?.isReachable ?? false
    }
}
