//
//  AlertController.swift
//  About Canada
//
//  Created by apple on 6/7/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
import  UIKit
class AlertController {
    
    class func alert(object:UIViewController,tilte:String,message:String) {
        
        let alertController = UIAlertController(title: tilte, message: message, preferredStyle:UIAlertController.Style.alert)
        
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
        { action -> Void in
            
            
            
        })
        object.present(alertController, animated: true, completion: nil)
        
    }
}
