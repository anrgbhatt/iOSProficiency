//
//  CanadaInfoTableViewCell.swift
//  About Canada
//
//  Created by apple on 6/6/19.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit

class CanadaInfoTableViewCell: UITableViewCell {

    @IBOutlet  var dscription: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var viewSuper: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        viewSuper.shadowCell()
        // Round image
        img.layer.masksToBounds = false
        img.layer.cornerRadius = img.frame.height/2
        img.clipsToBounds = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
// Shadow for tableview cell
extension UIView {
    func shadowCell(){
        layer.cornerRadius = 5
        backgroundColor = UIColor.white
        layer.shadowColor = UIColor.lightGray.cgColor
        layer.shadowOpacity = 1
        layer.shadowOffset = CGSize.zero
        layer.shadowRadius = 3
        
    }
}
