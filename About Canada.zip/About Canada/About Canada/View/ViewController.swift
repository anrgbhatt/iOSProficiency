//
//  ViewController.swift
//  About Canada
//
//  Created by apple on 5/31/19.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import SDWebImage
class ViewController: UIViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var tblAboutCanada: UITableView!
    var aboutCanada: [AboutCanada]?
    var refreshControl = UIRefreshControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        tblAboutCanada.rowHeight = UITableView.automaticDimension
        tblAboutCanada.estimatedRowHeight = 100
        self.tblAboutCanada.separatorStyle = UITableViewCell.SeparatorStyle.none
        tblAboutCanada.dataSource = self
        tblAboutCanada.delegate = self
        tblAboutCanada.register(UINib(nibName: "CanadaInfoTableViewCell", bundle: nil), forCellReuseIdentifier: GlobalConst.canadaTableViewIdentifier)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //Add pull to refresh
        refreshControl.attributedTitle = NSAttributedString(string: GlobalConst.tableRefreshMsg)
        refreshControl.addTarget(self, action: #selector(refreshTable), for: UIControl.Event.valueChanged)
        tblAboutCanada.addSubview(refreshControl)
        getDataFromServer()
    }
    
    //Get data (About Canada)
    func getDataFromServer(){
        activityIndicator.startAnimating()
        viewModel().getCanadaData(obj: self) { (data) in
            self.activityIndicator.stopAnimating()
            self.refreshControl.endRefreshing()
            self.aboutCanada = data
            self.tblAboutCanada.isHidden = false
            self.tblAboutCanada.reloadData()
        }
    }
    
    //Refresh the table
    @objc func refreshTable(sender:AnyObject) {
        getDataFromServer()
    }
}


//Table view delegate
extension ViewController:UITableViewDataSource,UITableViewDelegate  {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.aboutCanada?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:CanadaInfoTableViewCell?
        cell = tableView.dequeueReusableCell(withIdentifier: GlobalConst.canadaTableViewIdentifier)! as? CanadaInfoTableViewCell
        let des = self.aboutCanada![indexPath.row]
        cell?.dscription.text = des.description
        cell?.title.text = des.title
        self.title = des.countryTitle
        
        cell?.img.sd_setImage(with: URL(string: des.Image!), placeholderImage: UIImage(named: GlobalConst.tableviewPlaceholderImg))
        return cell!
    }
    
    
}


