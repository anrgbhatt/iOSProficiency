//
//  ViewController.swift
//  About Canada
//
//  Created by apple on 5/31/19.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import SDWebImage
class ViewController: UIViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var tblAboutCanada: UITableView!
    var aboutCanada: [AboutCanada]?
    var refreshControl = UIRefreshControl()
    var dataSource:AboutCanadaDataSource?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblAboutCanada.isHidden = true
        tblAboutCanada.rowHeight = UITableView.automaticDimension
        tblAboutCanada.estimatedRowHeight = 100
        self.tblAboutCanada.separatorStyle = UITableViewCell.SeparatorStyle.none
        tblAboutCanada.register(UINib(nibName: "CanadaInfoTableViewCell", bundle: nil), forCellReuseIdentifier: GlobalConst.canadaTableViewIdentifier)
    }
    //Add pull to refresh
    override func viewWillAppear(_ animated: Bool) {
        refreshControl.attributedTitle = NSAttributedString(string: GlobalConst.tableRefreshMsg)
        refreshControl.addTarget(self, action: #selector(refreshTable), for: UIControl.Event.valueChanged)
        tblAboutCanada.addSubview(refreshControl)
        getDataFromServer()
    }
    
    //Get data (About Canada)
    func getDataFromServer(){
        activityIndicator.startAnimating()
        viewModel().getCanadaData(obj: self) { (data) in
            self.title = (data[0]).countryTitle
            self.dataSource  = AboutCanadaDataSource(data: data)
            self.activityIndicator.stopAnimating()
            self.refreshControl.endRefreshing()
            self.tblAboutCanada.dataSource = self.dataSource
            self.aboutCanada = data
            self.tblAboutCanada.isHidden = false
            self.tblAboutCanada.reloadData()
        }
    }
    
    //Refresh the table
    @objc func refreshTable(sender:AnyObject) {
        getDataFromServer()
    }
}




