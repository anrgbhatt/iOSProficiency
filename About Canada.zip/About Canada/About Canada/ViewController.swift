//
//  ViewController.swift
//  About Canada
//
//  Created by apple on 5/31/19.
//  Copyright © 2019 apple. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import SDWebImage
class ViewController: UIViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var tblAboutCanada: UITableView!
    let sharedInstance = CandaInfoDataSource.sharedInstance
    var aboutCanada: [AboutCanada]?
    var refreshControl = UIRefreshControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblAboutCanada.isHidden = true
        tblAboutCanada.rowHeight = UITableView.automaticDimension
        tblAboutCanada.estimatedRowHeight = 100
        self.tblAboutCanada.separatorStyle = UITableViewCell.SeparatorStyle.none
        getDataFromServer()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //Add pull to refresh
        refreshControl.attributedTitle = NSAttributedString(string: "Refreshing..")
        refreshControl.addTarget(self, action: #selector(refreshTable), for: UIControl.Event.valueChanged)
        tblAboutCanada.addSubview(refreshControl)
    }
    

    //Hit Api Get Data populate in table view
    func getDataFromServer(){
        activityIndicator.startAnimating()
        if NetworkObserver.isConnectedToInternet() {
            sharedInstance.getData(url:Bundle.main.object(forInfoDictionaryKey: "webURl") as! String ) { (data) in
                self.activityIndicator.startAnimating()
                self.refreshControl.endRefreshing()
                if data.count < 1 {
                    self.activityIndicator.stopAnimating()
                  AlertController.alert(object: self, tilte: "Error", message: "No Data found!")
                }else{
                    self.aboutCanada = data
                    self.tblAboutCanada.isHidden = false
                    self.tblAboutCanada.reloadData()
                }
            }
        }else{
            self.activityIndicator.stopAnimating()
            AlertController.alert(object: self, tilte: "Error", message: "No internet conection!")
        }
    }
    
    //Hit Api
    @objc func refreshTable(sender:AnyObject) {
        getDataFromServer()
    }
}


//Table view delegate
extension ViewController:UITableViewDataSource,UITableViewDelegate  {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.aboutCanada?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:CanadaInfoTableViewCell?
        cell = tableView.dequeueReusableCell(withIdentifier: "CellContactorListTableViewCell")! as? CanadaInfoTableViewCell
        let des = self.aboutCanada![indexPath.row]
        cell?.dscription.text = des.description
        cell?.title.text = des.title
        self.title = des.countryTitle
        
        cell?.img.sd_setImage(with: URL(string: des.Image!), placeholderImage: UIImage(named: "placeholder-image"))
        return cell!
    }
    
}


