//
//  ViewModel.swift
//  About Canada
//
//  Created by apple on 6/10/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
import UIKit

class viewModel {
    let sharedInstance = CandaInfoDataSource.sharedInstance
    
    //Hit Api and get contents for table
    func getCanadaData(obj:UIViewController ,completion: @escaping ([AboutCanada]) -> Void){
        if NetworkObserver.isConnectedToInternet() {
        sharedInstance.getData(url:Bundle.main.object(forInfoDictionaryKey: "webURl") as! String ) { (data) in
                if data.count < 1 {
                    AlertController.alert(object: obj, tilte: GlobalConst.errorText, message: GlobalConst.tableviewNoDataMsg)
                }else{
                    completion(data)
                }
            }
        }else{
            AlertController.alert(object: obj, tilte: GlobalConst.errorText, message: GlobalConst.noInternetMsg)
        }
    
    }
}
