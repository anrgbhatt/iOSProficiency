//
//  About_CanadaUITests.swift
//  About CanadaUITests
//
//  Created by apple on 6/10/19.
//  Copyright © 2019 apple. All rights reserved.
//

import XCTest
@testable import About_Canada
class About_CanadaUITests: XCTestCase {
    var vc:ViewController!
    var dataSource: ViewController!
    let tableView = UITableView()
    var aboutCanada: [AboutCanada] = []
    override func setUp() {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: GlobalConst.canadaTableViewIdentifier)
        tableView.estimatedRowHeight = 100
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        vc = storyboard.instantiateViewController(withIdentifier: "ViewController") as? ViewController
        _ = vc.view
        
        for number in 0..<10 {
            let dic  = ["title":"geography: \(number)","description":"description","imageHref":"https//hhweeyiy",]
            let dicAboutCanada = AboutCanada(dictionary: dic, countryTitle: "canada")
            self.aboutCanada.append(dicAboutCanada)
        }


}
    
    func testTableView(){

        XCTAssertNil(vc.tblAboutCanada)
        
    }
    
    func testTableViewDataSource(){


        XCTAssertTrue(vc.tblAboutCanada.dataSource is ViewController)
        
    }
    
    func testTableViewDelegate(){
        XCTAssertTrue(vc.tblAboutCanada.delegate is ViewController)
        
    }
    
    func testDataSourceDelegateSameInstance(){
        XCTAssertEqual(vc.tblAboutCanada.dataSource as! ViewController, vc.tblAboutCanada.delegate as! ViewController)
        
    }
    
    
    func testDataSourceHasInfo() {
        XCTAssertEqual(aboutCanada.count, 10,
                       "DataSource should have correct number of info")
    }
    
    func testNumberOfRows() {
        let numberOfRows = dataSource.tableView(tableView, numberOfRowsInSection: 0)
        XCTAssertEqual(numberOfRows, 10,
                       "Number of rows in table should match number of info")
    }
    
    func testCellForRow() {
        let cell = dataSource.tableView(tableView, cellForRowAt: IndexPath(row: 0, section: 0))
        XCTAssertEqual(cell.textLabel?.text, "geography: 0",
                       "The first cell should display name of first info")
    }
    
}
